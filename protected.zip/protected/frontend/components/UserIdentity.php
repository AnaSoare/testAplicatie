<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity {

	/*----------------------------- Const Var --------------------------*/
	const ERROR_STATUS_DISABLE=5;
	const ERROR_STATUS_OBJECT_NOT_FOUND = 404;
	/*------------------------------------------------------------------*/
	
	
	/*--------------------------- Private Var --------------------------*/
	private $_id;
	private $_username;
	/*------------------------------------------------------------------*/
	
	
	/*---------------------------- Public Var --------------------------*/



	public function authenticate() {
		/* Check if the user try to login in other methods.
		 * Example : facebook, google, twitter.
		 */
		$user = null;
		$userRoleLevel = null;


		$user = User::model()->findByAttributes(array(
			'email' => CHtml::encode($this->username)
		));

		if($user === null) {
			$this->errorCode=self::ERROR_USERNAME_INVALID;

		} elseif ($user->password !== md5($this->password)) {
			$this->errorCode = self::ERROR_PASSWORD_INVALID;

		}elseif ($user->status == User::STATUS_DISABLE) {
			$this->errorCode = self::ERROR_STATUS_DISABLE;
		}

		else {
			$this->_id = $user->id;

			$this->_username = $user->email;

			$this->errorCode = self::ERROR_NONE;
		}


		return !$this->errorCode;
	}


	public function getId() { return $this->_id; }	
	public function getName() {return $this->_username; }

}