<?php

class WebUser extends CWebUser {

	public function checkAccess($operation, $params = array()) {
		$userRoleLevel = null;

		if(empty($this->id)) {
			return false;
		}

		$user = User::model()->findByPk($this->id);
		$userRoleLevel = (int)$user->role->level;

		if(is_array($operation)) {

			foreach($operation as $value) {
				if($value == $userRoleLevel) {
					return true;
				}
			}

		return false;

		} else {
			return ($operation == $userRoleLevel);
		}
	}


}


