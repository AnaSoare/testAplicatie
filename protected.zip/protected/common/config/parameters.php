<?php
require_once(dirname(dirname(__FILE__)) . '/models/User.php');

return array(
	'imageDir' => '/public/upload/images/',

	'phpThumbOptions' => array(
		'jpegQuality' => 87,
		'preserveAlpha' => true,
		'preserveTransparency' => true
	),

	'userAvatar' => array(
		'defaultFilename' => 'guest_avatar.png',
		'size' => array(
			'width' => 45,
			'height' => 45
		),

		/* 	Settings for default avatar. (if the user has no avatar).
			Maybe we want to change the default avatar in the future.
		*/
		'wipe' => false,
		'wipeCache' => false,
	),

	'userStatus' => array(
		User::STATUS_ACTIVE 		=> 'Activ',
		User::STATUS_DISABLE 		=> 'Dezactivat',
	),

	'adminEmail' => array('registration-no-reply@domeniu.org' => 'domeniu.org'),
	'contactEmail' => 'contact@domeniu.org',

	'phpbrowscapSystem' => array(
		'cache' => '/protected/frontend/runtime/'
	),

	/* In minutes. */
	'tokenLifetime' => array(
		'onResetPassword' => (60 * 60) * 24 * 31 /* 1 Month. */,
	),

	'facebook' => array (
		'appId' => '',
		'secret' => '',
		'scope' => 'email, user_birthday',
	),

	'google' => array (
		'appId' => '.apps.googleusercontent.com',
		'secret' => '',
		'redirect' => '',
		'scope' => array (
			'https://www.googleapis.com/auth/userinfo.profile',
			'https://www.googleapis.com/auth/userinfo.email',
		)
	),

	'twitter' => array (
		'appId' => '',
		'secret' => '',
		'scope' => '',
	),

	'googleAnalytics' => array(
		'account' => '',
		'enable' => false,
	),
);