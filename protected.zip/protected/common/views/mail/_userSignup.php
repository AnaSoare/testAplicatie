Bine ai venit: <br>
Esti inregistrat cu:<br>
E-mail: <?php echo $user->email; ?> <br>
Parola: <?php echo $user->password_unmodified; ?>

