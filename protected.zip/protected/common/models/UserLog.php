<?php

/**
 * This is the model class for table "user_log".
 *
 * The followings are the available columns in table 'user_log':
 * @property integer $id
 * @property integer $user_id
 * @property string $ip
 * @property string $browser
 * @property string $description
 * @property string $created_at
 */
class UserLog extends CActiveRecord {


	public static function model($className = __CLASS__) {
		return parent::model($className);
	}


	public function tableName() {
		return 'user_log';
	}


	public function rules() {
		return array(
			array('user_id, ip', 'required'),
			array('user_id', 'numerical', 'integerOnly' => true),
			array('ip', 'length', 'max' => 255),
			array('browser, description', 'length', 'max' => 2048),
			array('created_at', 'safe'),


			array(
				'created_at',
				'default', 'value' => new CDbExpression('NOW()'),
				'setOnEmpty' => false,
				'on' => array('insert', 'signup', 'createUser')
			),


			array('id, user_id, ip, browser, description, created_at', 'safe', 'on' => 'search'),
		);
	}


	public function relations() {
		return array();
	}


	public function attributeLabels() {
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'ip' => 'Ip',
			'browser' => 'Browser',
			'description' => 'Description',
			'created_at' => 'Created At',
		);
	}


	public function search() {
		$criteria = new CDbCriteria();


		$criteria->compare('id', $this->id);
		$criteria->compare('user_id', $this->user_id);
		$criteria->compare('ip', $this->ip, true);
		$criteria->compare('browser', $this->browser, true);
		$criteria->compare('description', $this->description, true);
		$criteria->compare('created_at', $this->created_at, true);


		return new CActiveDataProvider($this, array(
			'criteria' => $criteria,
		));
	}


}
