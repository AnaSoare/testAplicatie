<?php

Yii::import('bootstrap.widgets.TbButtonColumn');

class EvalButtonColumn extends TbButtonColumn {


	public function renderDataCellContent($row, $data) {
		$tr = array();

		ob_start();

		foreach($this->buttons as $id => $button) {

			/* Evaluate Icon. */
			$button['icon'] = $this->evaluateExpression($button['icon'], array('row' => $row, 'data' => $data));

			/* Evaluate options. */
			foreach($button['options'] as $key => $value) {
				$button['options'][$key] = $this->evaluateExpression($button['options'][$key], array('row' => $row, 'data' => $data));
			}


			$this->renderButton($id, $button, $row, $data);

			$tr['{'.$id.'}'] = ob_get_contents();

			ob_clean();
		}

		ob_end_clean();

		echo strtr($this->template, $tr);
	}

}