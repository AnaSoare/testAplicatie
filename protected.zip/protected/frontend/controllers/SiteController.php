<?php

class SiteController extends Controller {

	/**
	 * @return array action filters
	 */
	public function filters() {
		return array(
			'accessControl',
		);
	}


	public function accessRules() {
		return array(
			array(
				'allow',
				'actions' => array('error'),
				'users' => array('*'),
			),

			array(
				'allow',
				'actions' => array('index'),
				'users' => array('@'),
			),

			array(
				'deny',
				'users' => array('*'),
			),
		);
	}



	public function actionIndex() {
		$data = array();

		$this->pageTitle = Yii::app()->name;
		$user_id = Yii::app()->user->id;

		$tasks = Task::model()->findAllByAttributes(array('assigned_to'=>$user_id), array('order'=>'due_date', 'limit'=>6));
		$projects = Project::model()->findAllByAttributes(array('status'=>'active'), array('order'=>'created_at', 'limit'=>6));

		$data['tasks'] = $tasks;
		$data['projects'] = $projects;

		$this->render('index', $data);
	}
}