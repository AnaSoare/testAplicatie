<?php


class EmailManager
{


	/* @param array $params */
	public static function sendDebugEmail($params)
	{

		try {
			$data = array();
			$subject = '';
			$to = Yii::app()->params['debug']['email']['send_to'];
			$bcc = Yii::app()->params['debug']['email']['bcc_to'];


			$subject = (empty($params['subject']) == false) ? $params['subject'] : $subject;
			$to = (empty($params['to']) == false) ? CMap::mergeArray($params['to'], $to) : $to;
			$bcc = (empty($params['bcc']) == false) ? CMap::mergeArray($params['bcc'], $bcc) : $bcc;
			$data['data'] = (empty($params['data']) == false) ? $params['data'] : array();


			$message = new YiiMailMessage();
			$message->subject = $subject;


			/* Template from protected/common/views/mail. */
			$message->layout = 'blank';
			$message->view = '_debug';
			$message->from = Yii::app()->params['adminEmail'];
			$message->sender = Yii::app()->params['adminEmail'];


			$message->setBody($data, 'text/html');


			/* Send to. */
			foreach ($to as $send_to) {
				$message->addTo($send_to);
			}


			/* BCC. */
			foreach ($bcc as $bcc_to) {
				$message->addBcc($bcc_to);
			}


			$headers = $message->getHeaders();


			Yii::app()->mail->send($message);


		} catch (Exception $e) {

			mTHelper::writeLogFile(
				Yii::app()->params['file_logs']['email'],
				($e->getMessage() . "\n" . $e->getTraceAsString())
			);

		}

	}


	/* @param User $user */
	public static function sendEmailOnSignUp(User $user)
	{

		try {
			$data = array();
			$data['user'] = $user;


			$message = new YiiMailMessage();
			$message->subject = Yii::t('email', 'controllers.user.signup.0001');


			/* ------------------------------------------ */
			/* Template from protected/common/views/mail. */
			/* ------------------------------------------ */
			$message->layout = 'main';
			$message->view = '_userSignup';
			$message->from = 'ana.sora@diamondconsulting.ro';
			$message->sender = 'ana.sora@diamondconsulting.ro';


			/* Embed image. */
//			$cid = $message->embed(Swift_Image::fromPath(
//				Yii::getPathOfAlias('webroot') . '/public/common/images/email/placeholder_800.png')
//			);
//			$data['cid'] = $cid;


			$message->setBody($data, 'text/html');
			$message->addTo($user->email);


			$headers = $message->getHeaders();
			$headers->addTextHeader('Reply-To', Yii::app()->params['mail_reply_to']);


			Yii::app()->mail->send($message);


		} catch (Exception $e) {

			mTHelper::writeLogFile(
				Yii::app()->params['file_logs']['email'],
				($e->getMessage() . "\n" . $e->getTraceAsString())
			);

		}

	}


	/* @param User $user */
	public static function sendEmailOnResetPassword(User $user)
	{

		try {
			$data = array();
			$data['user'] = $user;

			$message = new YiiMailMessage();
			$message->subject = Yii::t('email', 'Reset password');
			
			/* ------------------------------------------ */
			/* Template from protected/common/views/mail. */
			/* ------------------------------------------ */

			//$message->layout = 'main';
			$message->view = '_userResetPassword';
			$message->from = 'ana.sora@diamondconsulting.ro';
			$message->sender = 'ana.sora@diamondconsulting.ro';
			
			//CVarDumper::dump($user,10,true);die();
			/* Embed image. */
//			$cid = $message->embed(Swift_Image::fromPath(
//				Yii::getPathOfAlias('webroot') . '/public/common/images/email/placeholder_800.png')
//			);
//			$data['cid'] = $cid;

			$message->setBody($data, 'text/html');
			$message->addTo($user->email);

			$headers = $message->getHeaders();
			$headers->addTextHeader('Reply-To', Yii::app()->params['mail_reply_to']);

			//CVarDumper::dump($message,10,true);
			Yii::app()->mail->send($message);


		} catch (Exception $e) {

			mTHelper::writeLogFile(
				Yii::app()->params['file_logs']['email'],
				($e->getMessage() . "\n" . $e->getTraceAsString())
			);

		}

	}

}