<?php

class TaskStatusController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout = '//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions' => array('index', 'view'),
				'users' => array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions' => array('create', 'update', 'admin', 'delete'),
				'users' => array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions' => array(),
				'users' => array('admin'),
			),
			array('deny',  // deny all users
				'users' => array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$data = [];
		$model = $this->loadModel($id);
		$tasks = new Task('searchByTaskStatus');

		$projectList = CHtml::listData(Project::model()->findAllByAttributes(array('status' => 'active')), 'id', 'name');
		$taskStatusList = CHtml::listData(TaskStatus::model()->findAll(), 'id', 'name');


		$data['model'] = $model;
		$data['tasks'] = $tasks;
		$data['projectList'] = $projectList;
		$data['taskStatusList'] = $taskStatusList;

		$this->render('view',$data);
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$data = [];
		$model = new TaskStatus;
		$taskStatusList = TaskStatus::model()->findAll();

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if (isset($_POST['TaskStatus'])) {

			$model->attributes = $_POST['TaskStatus'];

			if ($model->save()) {
				Yii::app()->user->setFlash('success', "The task status has been added");
				$this->redirect(array('update', 'id' => $model->id));
			}
		}

		$data['model'] = $model;
		$data['taskStatusList'] = $taskStatusList;

		$this->render('create',$data);
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$data = [];
		$model = $this->loadModel($id);

		$taskStatusList = TaskStatus::model()->findAll();

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if (isset($_POST['TaskStatus'])) {
			$model->attributes = $_POST['TaskStatus'];

			if($model->save()) {
				Yii::app()->user->setFlash('success', "The task status has been updated");
				$this->redirect(array('update', 'id' => $model->id));
			}
		}

		$data['model'] = $model;
		$data['taskStatusList'] = $taskStatusList;

		$this->render('update', $data);
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if (!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider = new CActiveDataProvider('TaskStatus');
		$this->render('index', array(
			'dataProvider' => $dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$data = [];
		$model = new TaskStatus('search');

		$taskStatusList = TaskStatus::model()->findAll();

		$model->unsetAttributes();  // clear any default values
		if (isset($_GET['TaskStatus']))
			$model->attributes = $_GET['TaskStatus'];


		$data['model'] = $model;
		$data['taskStatusList'] = $taskStatusList;

		$this->render('admin', $data);
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return TaskStatus the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model = TaskStatus::model()->findByPk($id);
		if ($model === null)
			throw new CHttpException(404, 'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param TaskStatus $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if (isset($_POST['ajax']) && $_POST['ajax'] === 'task-status-form') {
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
