<?php

class ExtendedLogger extends CFileLogRoute {


	protected function formatLogMessage($message, $level, $category, $time) {
		$value 			= '';
		$ip_address 	= $_SERVER['REMOTE_ADDR'];
		$message		.= "\nREMOTE_IP = {$ip_address}";
		$message		.= "\n" . str_repeat('-', 60) . "\n\n";
		$_list 			= array(
			array(
				'message' 	=> @date('Y-m-d H:i:s', $time),
				'template' 	=> '%message%',
			),

			array(
				'message' 	=> $level,
				'template' 	=> ' [%message%] ',
			),

			array(
				'message' 	=> $category,
				'template' 	=> ' [%message%] ',
			),

			array(
				'message' 	=> $message,
				'template' 	=> ' %message% ',
			),
		);


		foreach($_list as $_l_item) {

			if(empty($_l_item['message']) == false) {
				$value .= str_replace('%message%', $_l_item['message'], $_l_item['template']);
			}

		}


		$value .= "\n";


		return  $value;
	}


	public function processLogs($logs) {
		parent::processLogs($logs);
	}

}