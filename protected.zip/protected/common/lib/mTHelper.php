<?php


class mTHelper extends CHtml {


	public static function disableBaseScripts() {
		/* Remove the script path. */
		$clientScript = Yii::app()->clientScript;


		/* Disable CSS. */
		$clientScript->scriptMap['bootstrap.min.css'] = false;
		$clientScript->scriptMap['bootstrap.css'] = false;
		$clientScript->scriptMap['bootstrap-responsive.min.css'] = false;
		$clientScript->scriptMap['yii.css'] = false;


		/* Disable Javascript. */
		$clientScript->scriptMap['jquery.js'] = false;
		$clientScript->scriptMap['jquery.min.js'] = false;
		$clientScript->scriptMap['jquery-ui.min.js'] = false;
		$clientScript->scriptMap['jquery-ui.js'] = false;

		$clientScript->scriptMap['bootstrap.js'] = false;
		$clientScript->scriptMap['bootstrap.min.js'] = false;
		/* ----------------------------------------------------------------- */
	}


	public static function getEnumItems($model, $attribute) {
		$value = array();

		$attr = $attribute;

		preg_match('/\((.*)\)/', $model->tableSchema->columns[$attr]->dbType, $matches);
		$enums = explode(',', $matches[1]);

		for($i = 0; $i < count($enums); $i++) {
			$v = str_replace("'", null, $enums[$i]);

			$value[$v] = Yii::t('enumItem', $v);;
		}

		return $value;
	}


	public static function stringFriendly($string) {
		return strtolower(preg_replace(array('/[^a-zA-Z0-9 -]/', '/[ -]+/', '/^-|-$/'), array('', '-', ''), $string));
	}


	public static function getYearList($start, $end, $invers = false) {
		$value = array();


		for($i = $start; $i <= $end; $i++) {
			$value[$i] = $i;
		}


		if($invers == true) {
			$value = array_reverse($value, true);
		}


		return $value;
	}


	public static function getMonthList($as_numeric = true) {
		$value = array(
			'01' 	=> 'January',
			'02' 	=> 'February',
			'03' 	=> 'March',
			'04' 	=> 'April',
			'05' 	=> 'May',
			'06' 	=> 'June',
			'07' 	=> 'July',
			'08' 	=> 'August',
			'09' 	=> 'September',
			'10' 	=> 'October',
			'11' 	=> 'November',
			'12' 	=> 'December',
		);

		if($as_numeric == true) {
			$value = array();

			for($i = 1; $i <= 12; $i++) {
				$value[sprintf("%02d", $i)] = sprintf("%02d", $i);
			}
		}


		return $value;
	}


	public static function getDayList($invers = false) {
		$value = array();


		for($i = 1; $i <= 31; $i++) {
			$value[sprintf("%02d", $i)] = sprintf("%02d", $i);
		}


		if($invers == true) {
			$value = array_reverse($value, true);
		}


		return $value;
	}


	public static function downloadFile($url, $options = array()) {
		if(!is_array($options)) {
			$options = array();
		}


		$options = CMap::mergeArray(array(
			'connectionTimeout' => 5,
			'timeout' => 10,
			'sslVerifyPeer' => false,
			'followLocation' => false,
			'maxRedirs' => 1,
		), $options);


		/* create a temporary file (we are assuming that we can write to the system's temporary directory) */
		$tempFileName = tempnam(sys_get_temp_dir(), '');
		$fh = fopen($tempFileName, 'w');


		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_FILE, $fh);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 	$options['connectionTimeout']);
		curl_setopt($curl, CURLOPT_TIMEOUT, 		$options['timeout']);
		curl_setopt($curl, CURLOPT_HEADER, 			false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 	$options['sslVerifyPeer']);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 	$options['followLocation']);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 		$options['maxRedirs']);
		curl_exec($curl);


		curl_close($curl);
		fclose($fh);

		return $tempFileName;
	}


	public static function summarize($text, $length, $type = "words", $stripTags = false) {
		$value = '';
		$append = "...";

		if($stripTags) {
			$text = strip_tags($text);
		}

		if(strlen($text) < $length) {
			$value = $text;

		} elseif($type == "words") {
			$endp = $length - strlen($append);

			while ($endp > 0 && strlen(chop(substr($text, $endp, 1)))) {
				$endp--;
			}

			if(!$endp) {
				$endp = $length - strlen($append);
			}

			$value = chop(substr($text,0,$endp)) . $append;

		} elseif($type == "letters") {
			$value = chop(substr($text, 0, $length)) . $append;

		}

		return $value;
	}


	public static function base64EncodeImage($filename = "", $filetype = "png") {
		$value = 'data:image/' . $filetype . ';';

		if(strlen($filename) > 0) {
			try {
				$imgbinary = fread(fopen($filename, "r"), filesize($filename));

				$value = 'data:image/' . $filetype . ';base64,' . base64_encode($imgbinary);

			} catch (Exception $e) {
			}
		}

		return $value;
	}


	public static function createDirectory($path) {
		$value = is_dir($path) || @mkdir($path, 0775, true);

		return $value;
	}


	public static function cleanAllFolders($dir, $deleteRootDir = false) {
		$value = true;

		$files = array_diff(scandir($dir), array('.', '..'));


		foreach ($files as $file) {
			if(is_dir($dir . $file)) {
				self::cleanAllFolders($dir . $file . "/", true);

			} else {
				unlink($dir . $file);
			}
		}


		if($deleteRootDir == true) {
			$value = rmdir($dir);
		}


		return true;
	}


	public static function writeLogFile($file_name, $message) {
		$file_log 		= new ExtendedLogger();
		$max_file_size 	= 10 * 1024;
		$log_path 		= Yii::getPathOfAlias('application') . '/runtime/';
		$rotate_by_copy = true;
		$max_log_files 	= 10;


		$file_log->rotateByCopy = $rotate_by_copy;

		$file_log->setLogPath( $log_path );
		$file_log->setLogFile( $file_name );
		$file_log->setMaxFileSize( $max_file_size );
		$file_log->setMaxLogFiles( $max_log_files );
		$file_log->init();


		$file_log->processLogs(
			array(
				array(
					$message, '', '', strtotime(date('Y-m-d H:i:s'))
				)
			)
		);
	}


	public static function buildRoute($route, $params = array()) {
		$value              = '';
		$language 			= Yii::app()->language;
		$default_language 	= Yii::app()->params['languages']['default'];


		/* Ne asiguram ca nu vine cu lanuage setat de programator. */
		if(is_array($route) == true) {

			if(empty($route['language']) == false) {
				unset($route['language']);
			}

		} else {

			if(empty($params['language']) == false) {
				unset($params['language']);
			}

		}


		/* Default Language este RO...deci nu avem nevoie de acel language din route, dar pt. restul DA. */
		if($language != $default_language) {

			if(is_array($route) == true) {
				$route['language'] = $language;
			} else {
				$params['language'] = $language;
			}

		}


		if(is_array($route) == true) {
			$value = $route;

		} else {

			$value = array(
				'route'     => $route,
				'params'    => $params,
			);

		}


		return $value;
	}


	public static function getCountiesList() {
		$value = array();

		$counties = Yii::app()->db->createCommand("SELECT * FROM county order by non_utf8_name ASC")->queryAll();

		foreach($counties as $county) {
			$value[$county['id']] = $county['non_utf8_name'];
		}

		return $value;
	}


	public static function getProductList() {

		$value = array();

		$products = Yii::app()->db->createCommand("
					SELECT  `p_i18n`.`name`, `p`.* FROM `product` `p`
					LEFT JOIN `product_i18n` `p_i18n` ON `p_i18n`.`i18n_id` = `p`.`id`
					WHERE `p_i18n`.`locale` = 'ro'
 					order by name ASC")->queryAll();
		if(isset($products) && !empty($products)) {
			foreach ($products as $product) {
				$value[$product['id']] = $product['name'];
			}
		}

		return $value;
	}


	public static function subscribeToMailChimpListContact($email = null, $fname = null, $lname = null) {
		$value 		= '';
		$response  	= array();
		$email     	= $email;

		$mc_api_key   = Yii::app()->params['MailChimp']['ApiKey'];
		$mc_list_id   = Yii::app()->params['MailChimp']['ListId']['ActiveRegistered'];
		$mc_frequencies  = Yii::app()->params['MailChimp']['segment']['frequency'];
		$mc_api    = new MailChimp($mc_api_key);
		$email_hash   = $mc_api->subscriberHash($email);
		$frequency_name  = '';


		$mc_merge_vars   = array();
		$mc_email_type   = 'html';

		$mc_merge_vars['FNAME'] = $fname;
		$mc_merge_vars['LNAME'] = $lname;

		$response = $mc_api->put("lists/{$mc_list_id}/members/{$email_hash}", array(
			'email_type'  => $mc_email_type,
			'status'   => 'subscribed',
			'merge_fields'  => $mc_merge_vars,
			'email_address' => $email
		));



		if(empty($response['id']) == false) {
			$value = 'Success';
		}

		$l_error = $mc_api->getLastError();
		if(empty($l_error) == false) {
			$value = print_r($mc_api->getLastError(), true);
		}
		//CVarDumper::dump($l_error,10,true);die();
		$value = 'Return: ' . $value;


		return $value;
	}
	
		public static function subscribeToMailChimpListCatalog($email = null, $fname = null, $lname = null) {
		$value 		= '';
		$response  	= array();
		$email     	= $email;

		$mc_api_key   = Yii::app()->params['MailChimp']['ApiKey'];
		$mc_list_id   = Yii::app()->params['MailChimp']['ListId']['ListCatalog'];
		$mc_frequencies  = Yii::app()->params['MailChimp']['segment']['frequency'];
		$mc_api    = new MailChimp($mc_api_key);
		$email_hash   = $mc_api->subscriberHash($email);
		$frequency_name  = '';


		$mc_merge_vars   = array();
		$mc_email_type   = 'html';

		$mc_merge_vars['FNAME'] = $fname;
		$mc_merge_vars['LNAME'] = $lname;

		$response = $mc_api->put("lists/{$mc_list_id}/members/{$email_hash}", array(
			'email_type'  => $mc_email_type,
			'status'   => 'subscribed',
			'merge_fields'  => $mc_merge_vars,
			'email_address' => $email
		));



		if(empty($response['id']) == false) {
			$value = 'Success';
		}

		$l_error = $mc_api->getLastError();
		if(empty($l_error) == false) {
			$value = print_r($mc_api->getLastError(), true);
		}
		//CVarDumper::dump($l_error,10,true);die();
		$value = 'Return: ' . $value;


		return $value;
	}

}