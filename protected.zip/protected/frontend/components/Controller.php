<?php

class Controller extends CController {

	public $layout = '//layouts/main';
	public $menu = array();
	public $breadcrumbs = array();

	private $_dummy_user = null;


	public function getUserID() {
		return Yii::app()->user->id;
	}


	public function init() {
		if(!Yii::app()->user->isGuest) {
			$this->_dummy_user = User::model()->findByPk($this->getUserID());
		}
	}


	public function getUser() {
		$value = $this->_dummy_user;

		return $value;
	}


	public function actionError() {
		$error = Yii::app()->errorHandler->error;

		if($error) {
			if(Yii::app()->request->isAjaxRequest) {
				echo $error['message'];

			} else {
				$this->render('error', $error);

			}
		}
	}

}