<?php
Yii::setPathOfAlias('bootstrap', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'extensions/bootstrap/bootstrap');
Yii::setPathOfAlias('editable', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'extensions/x-editable');

//$frontend = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR;

$app_path 		= dirname( __DIR__ ) . DIRECTORY_SEPARATOR;
$protected_path = dirname( dirname( __DIR__ ) );

return array(
	'basePath' 			=> $protected_path,

	'name' => 'Test aplicatie',
	'charset' => 'UTF-8',

	'controllerPath' 	=> $app_path . 'controllers',
	'viewPath' 			=> $app_path . 'views',
	'runtimePath' 		=> $app_path . 'runtime',

	'defaultController' => 'site',


	'import' => array(
		'application.frontend.models.*',
		'application.frontend.components.*',

		'application.common.models.*',
		'application.common.extensions.*',
	),

	'modules' => array(
		'gii' => array(
			'class' => 'system.gii.GiiModule',
			'password' => 'gii',
			'ipFilters' => array("*"),
			'generatorPaths' => array(
				'bootstrap.gii',
			),
		),
	),

	'preload' => array(
		'bootstrap',
	),

	'components' => array(
		'clientScript' => array(
			'class' => 'CClientScript',
			'scriptMap' => array(
				'jquery.js' => false,
				'jquery.min.js' => false,
				'jquery-ui.js' => false,
				'jquery-ui.min.js' => false
			),
		),

		'user' => array(
			'class' => 'WebUser',
			'allowAutoLogin' => true,
			'loginUrl' => array('user/login'),
			'autoUpdateFlash' => false,
		),


		'bootstrap' => array(
			'class' => 'bootstrap.components.Bootstrap',
			'responsiveCss' => true,
		),

		'editable' => array(
			'class'     => 'editable.EditableConfig',
			'form'      => 'bootstrap',        //form style: 'bootstrap', 'jqueryui', 'plain'
			'mode'      => 'popup',            //mode: 'popup' or 'inline'
			'defaults'  => array(              //default settings for all editable elements
				'emptytext' => 'Click to edit'
			)
		),

	),
);