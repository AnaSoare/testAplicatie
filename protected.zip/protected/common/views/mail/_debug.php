<?php

	foreach ($data as $key => $value) {
		echo $key . "<br/>";
		print_r($value);
		echo "<br/>" . str_repeat('-', 60) . "<br/>";
	}

?>