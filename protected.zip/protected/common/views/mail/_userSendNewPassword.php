<p>
	<b>Buna ziua,</b>
</p>


<p>
	Pentru a accesa contul <?php echo Yii::app()->params['company']; ?> va puteti autentifica cu:
	<br><br>
	E-mail: <?php echo $user->email; ?> <br>
	Parola: <?php echo $user->parola; ?>
</p>


<p>
	Puteti accesa pagina de autentificare de pe <?php echo Yii::app()->params['company']; ?> la adresa
	<br>
	<a href="<?php echo $login_link_address; ?>"><?php echo $login_link_address; ?></a>
</p>




<br>


<p>Va dorim o zi excelenta!<br>Echipa <?php echo Yii::app()->params['company']; ?></p>