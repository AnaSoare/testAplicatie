<?php

class TaskController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout = '//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions' => array(),
				'users' => array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions' => array('create', 'update', 'admin', 'delete','index', 'view'),
				'users' => array('@'),
			),
//			array('allow', // allow admin user to perform 'admin' and 'delete' actions
//				'actions' => array('delete'),
//				'users' => array('admin'),
//			),
			array('deny',  // deny all users
				'users' => array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$data = [];
		$model =  $this->loadModel($id);

		$data['model'] = $model;

		$this->render('view', $data);
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$data = [];
		$model = new Task;
		$taskStatusHistory = new TaskStatusHistory();

		$projectList = CHtml::listData(Project::model()->findAllByAttributes(array('status' => 'active')), 'id', 'name');
		$taskStatusList = CHtml::listData(TaskStatus::model()->findAll(), 'id', 'name');
		$taskPriority = CHtml::listData(TaskPriority::model()->findAll(), 'id', 'name');
		$userList = CHtml::listData(User::model()->findAllBySql("SELECT `id`, CONCAT(`first_name`, ' ', `last_name`, '   ',`email`) as `last_name` FROM user WHERE `status` = 'active'"), 'id', 'last_name');
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if (isset($_POST['Task'])) {
			$model->name = $_POST['Task']['name'];
			$model->description = $_POST['Task']['description'];
			$model->project_id = $_POST['Task']['project_id'];
			$model->user_id = Yii::app()->user->id;
			$model->assigned_to = $_POST['Task']['assigned_to'];
			$model->status_id = $_POST['Task']['status_id'];
			$model->due_date = $_POST['Task']['due_date'];
			$model->task_priority_id = $_POST['Task']['task_priority_id'];

			if ($model->save()) {
				$taskStatusHistory->task_id = $model->id;
				$taskStatusHistory->task_status_id = $model->status_id;
				$taskStatusHistory->assigned_to = $_POST['Task']['assigned_to'];

				if ($taskStatusHistory->save()) {
					Yii::app()->user->setFlash('success', "The task has been added.");
					$this->redirect(array('create'));
				}
			}
		}

		$data['model'] = $model;
		$data['projectList'] = $projectList;
		$data['taskStatusList'] = $taskStatusList;
		$data['userList'] = $userList;
		$data['taskStatusHistory'] = $taskStatusHistory;
		$data['taskPriority'] = $taskPriority;

		$this->render('create', $data);
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$data = [];
		$model = $this->loadModel($id);
		$taskStatusHistory = new TaskStatusHistory();

		$projectList = CHtml::listData(Project::model()->findAllByAttributes(array('status' => 'active')), 'id', 'name');
		$taskStatusList = CHtml::listData(TaskStatus::model()->findAll(), 'id', 'name');
		$taskPriority = CHtml::listData(TaskPriority::model()->findAll(), 'id', 'name');
		$userList = CHtml::listData(User::model()->findAllBySql("SELECT `id`, CONCAT(`first_name`, ' ', `last_name`, '   ',`email`) as `last_name` FROM user WHERE `status` = 'active'"), 'id', 'last_name');

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if (isset($_POST['Task'])) {
			$model->name = $_POST['Task']['name'];
			$model->description = $_POST['Task']['description'];
			$model->project_id = $_POST['Task']['project_id'];
			$model->assigned_to = $_POST['Task']['assigned_to'];
			$model->status_id = $_POST['Task']['status_id'];
			$model->due_date = $_POST['Task']['due_date'];
			$model->task_priority_id = $_POST['Task']['task_priority_id'];

			if ($model->update()) {
				$taskstatus = TaskStatusHistory::model()->findByAttributes(array('task_id'=>$model->id),  array('order' => 'id DESC'));
				if ($taskstatus->task_status_id != $_POST['Task']['status_id'] || $taskstatus->assigned_to != $_POST['Task']['assigned_to']) {
					$taskStatusHistory->task_id = $model->id;
					$taskStatusHistory->task_status_id = $_POST['Task']['status_id'];
					$taskStatusHistory->assigned_to = $_POST['Task']['assigned_to'];

					$taskStatusHistory->save();
				}

				Yii::app()->user->setFlash('success', "The task has been updated.");
				$this->redirect(array('update', 'id' => $model->id));
			};
		}


		$data['model'] = $model;
		$data['projectList'] = $projectList;
		$data['taskStatusList'] = $taskStatusList;
		$data['userList'] = $userList;
		$data['taskStatusHistory'] = $taskStatusHistory;
		$data['taskPriority'] = $taskPriority;

		$this->render('update', $data);
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$model = $this->loadModel($id);

		$taskStatusHistory = TaskStatusHistory::model()->findAllByAttributes(array('task_id'=>$id));

		foreach($taskStatusHistory as $item){
			$item->delete();
		}

		$model->delete();

		$this->redirect(array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider = new CActiveDataProvider('Task');
		$this->render('index', array(
			'dataProvider' => $dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$data = [];
		$model = new Task('search');
		$taskStatusHistory = new TaskStatusHistory;


		$projectList = CHtml::listData(Project::model()->findAllByAttributes(array('status' => 'active')), 'id', 'name');
		$taskStatusList = CHtml::listData(TaskStatus::model()->findAll(), 'id', 'name');
		$taskPriority = CHtml::listData(TaskPriority::model()->findAll(), 'id', 'name');
		$userList = CHtml::listData(User::model()->findAllBySql("SELECT `id`, CONCAT(`first_name`, ' ', `last_name`, '   ',`email`) as `last_name` FROM user WHERE `status` = 'active'"), 'id', 'last_name');

		$model->unsetAttributes();  // clear any default values
		if (isset($_GET['Task'])) {
			$model->attributes = $_GET['Task'];
		}

		$data['model'] = $model;
		$data['projectList'] = $projectList;
		$data['taskStatusList'] = $taskStatusList;
		$data['userList'] = $userList;
		$data['taskStatusHistory'] = $taskStatusHistory;
		$data['taskPriority'] = $taskPriority;

		$this->render('admin', $data);
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Task the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model = Task::model()->findByPk($id);
		if ($model === null)
			throw new CHttpException(404, 'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Task $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if (isset($_POST['ajax']) && $_POST['ajax'] === 'task-form') {
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
