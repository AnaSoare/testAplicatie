<?php
	if(!isset($content)) {
		$content = '';
	}

	echo $content . "\n";
?>