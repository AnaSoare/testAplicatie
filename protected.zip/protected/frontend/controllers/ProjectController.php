<?php

class ProjectController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','admin','delete'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array(),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$data = [];
		$model = $this->loadModel($id);

		$projectList = CHtml::listData(Project::model()->findAllByAttributes(array('status' => 'active')), 'id', 'name');
		$taskStatusList = CHtml::listData(TaskStatus::model()->findAll(), 'id', 'name');

		$tasks = new Task('searchByProject');

		$data['model'] = $model;
		$data['tasks'] = $tasks;
		$data['projectList'] = $projectList;
		$data['taskStatusList'] = $taskStatusList;

		$this->render('view',$data);
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$data = [];
		$model = new Project;

		$projectList = Project::model()->findAllByAttributes(array('status' => 'active'));

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Project'])) {
			$model->status = $_POST['Project']['status'];
			$model->name = $_POST['Project']['name'];
			$model->description = $_POST['Project']['description'];
			$model->due_date = '0000-00-00';

			if($model->save())
				Yii::app()->user->setFlash('success', "The project has been added");
				$this->redirect(array('update', 'id'=>$model->id));
		}

		$data['model'] = $model;
		$data['projectList'] = $projectList;

		$this->render('create',$data);
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$data = [];
		$model=$this->loadModel($id);

		$projectList = Project::model()->findAllByAttributes(array('status' => 'active'));
		$userList = CHtml::listData(User::model()->findAllBySql("SELECT `id`, CONCAT(`first_name`, ' ', `last_name`, '   ',`email`) as `last_name` FROM user WHERE `status` = 'active'"), 'id', 'last_name');

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Project']))
		{
			$model->attributes = $_POST['Project'];

			if($model->save()) {
				Yii::app()->user->setFlash('success', "The project has been updated");
				$this->redirect(array('update', 'id' => $model->id));
			}
		}

		$data['model'] = $model;
		$data['userList'] = $userList;
		$data['projectList'] = $projectList;

		$this->render('update', $data);
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Project');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$data = [];
		$model = new Project('search');
		$projectList = Project::model()->findAllByAttributes(array('status' => 'active'));

		$model->unsetAttributes();  // clear any default values

		if(isset($_GET['Project'])) {
			$model->attributes = $_GET['Project'];
		}

		$data['model'] = $model;
		$data['projectList'] = $projectList;

		$this->render('admin',$data);
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Project the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Project::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Project $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='project-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
