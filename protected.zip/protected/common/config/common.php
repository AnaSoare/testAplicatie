<?php
	Yii::setPathOfAlias('bootstrap', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'extensions/bootstrap');

	return array(
		'language' => 'en',

		'import' => array(
			'application.common.lib.mTHelper',
			'application.common.lib.phpThumb.Thumb',
			'application.common.extensions.mail.YiiMailMessage',
			'application.common.extensions.redactor.ERedactorWidget',
			'application.common.extensions.timepicker.EJuiDateTimePicker',
			'application.common.lib.Dmd',

			'application.common.extensions.custom-widgets.bootstrap.EvalButtonColumn',
		),


		'preload' => array(
			'log',
			'bootstrap',
		),


		/* application components. */
		'components' => array(
			'db' => array(
				'connectionString' => 'mysql:host=localhost; dbname=test',
				'emulatePrepare' => true,
				'username' => 'root',
				'password' => '',
				'charset' => 'utf8',
			),


			'bootstrap' => array(
				'class' => 'bootstrap.components.Bootstrap',
			),



			'mail' => array(
				'class' 				=> 'application.common.extensions.mail.YiiMail',
				'viewPath' 				=> 'application.common.views.mail',
				'logging' 				=> false,
				'dryRun' 				=> false,
				'transportType' 		=> 'smtp',
				'transportOptions' 		=> array(
					'host' 					=> 'mail.diamondconsulting.ro',
					'username' 				=> 'ana.sora@diamondconsulting.ro',
					'password' 				=> '-F.ovmMFE0WG',
					'port' 					=> '587',
					//'encryption' 			=> 'ssl',
				),
			),




			'ePdf' => array(
				'class' => 'application.common.extensions.yii-pdf.EYiiPdf',
				'params' => array(
					'HTML2PDF' => array(
						'librarySourcePath' => 'application.common.vendors.html2pdf.*',
						'classFile' => 'html2pdf.class.php',
						'defaultParams' => array(
							'orientation' => 'P',
							'format' => 'A4',
							'language' => 'en',
							'unicode' => true,
							'encoding' => 'UTF-8',
							'marges' => array(5, 5, 3, 0), /* margins by default, in order (left, top, right, bottom) */
						),
					),
				),
			),


			'widgetFactory' => array(
				'widgets' => array(
					'EvalButtonColumn' => array(

					),

					'ERedactorWidget' => array(
						'options' => array(
							'plugins' => array(
								//'fullscreen'
							),

							'buttons' => array(
								'formatting', '|', 'bold', 'italic', 'deleted', '|',
								'unorderedlist', 'orderedlist', 'outdent', 'indent', '|',
								'image', 'video', 'link', '|', 'html',
							),

							'fullpage' => 'true',
						),

						'htmlOptions' => array(
						)
					),
				),
			),


			'errorHandler' => array(
				'errorAction' => 'site/error',
			),
		),

		'params' => require_once (dirname(__FILE__) . DIRECTORY_SEPARATOR .'parameters.php'),
	);