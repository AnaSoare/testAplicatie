<p>
	<b>Buna ziua, <?php echo $user->first_name. ' ' . $user->last_name?> </b>
</p>


<p>
	Click pe link-ul de mai jos pentru a reseta parola
	<br>
	<br>
	<a href="<?php echo Yii::app()->createAbsoluteUrl('user/changePassword', ['token' => $user->token_reset_password]); ?>">Reseteaza parola</a>
	<br>
</p>

<br>

<p>Daca nu ati solicitat recuperarea parolei, va rugam ignorati acest mesaj.</p>