<?php
	return array(
		'components' => array(
			'db' => array(
				'connectionString' => 'mysql:host=localhost; dbname=test',
				'emulatePrepare' => true,
				'username' => 'root',
				'password' => '',
				'charset' => 'utf8',

				//'enableProfiling' => true,
				//'enableParamLogging' => true,
			),


			'mail' => array(
				'class' 				=> 'application.common.extensions.mail.YiiMail',
				'viewPath' 				=> 'application.common.views.mail',
				'logging' 				=> false,
				'dryRun' 				=> false,
				'transportType' 		=> 'smtp',
				'transportOptions' 		=> array(
					'host' 					=> 'mail.diamondconsulting.ro',
					'username' 				=> 'ana.sora@diamondconsulting.ro',
					'password' 				=> '-F.ovmMFE0WG',
					'port' 					=> '587',
					//'encryption' 			=> 'ssl',
				),
			),



			'log' => array(
				'class' => 'CLogRouter',
				'routes' => array(
					array(
						'class' => 'CFileLogRoute',
						'levels' => 'error, warning',
					),

					array(
						'class'=>'CWebLogRoute',
					),
				),
			),
		),

		'modules' => array(
			'gii' => array(
				'class' => 'system.gii.GiiModule',
				'password' => 'gii',
				'ipFilters' => array('*'),
				'generatorPaths' => array(
					'bootstrap.gii',
				),
			),
		),

		'params' => array(
			'adminEmail' => array('no-reply@domeniu.ro' => 'domeniu'),
			'contactEmail' => 'domeniu-contact@domeniu.ro',

			'facebook' => array (
				'appId' => '',
				'secret' => '',
				'scope' => 'email, user_birthday',
			),

			'google' => array (
				'appId' => '',
				'secret' => '',
				'redirect' => 'http://domeniu.ro/login',
				'scope' => array (
					'https://www.googleapis.com/auth/userinfo.profile',
					'https://www.googleapis.com/auth/userinfo.email',
				)
			),

			'twitter' => array (
				'appId' => '',
				'secret' => '',
				'scope' => '',
			),
		),
	);