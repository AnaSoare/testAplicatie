<?php
class Dmd{

public static function get_enum_values($model,$attribute)
	{
		$attr=$attribute;
		CHtml::resolveName($model,$attr);
		$enum=$model->tableSchema->columns[$attr]->dbType;
		$off=strpos($enum,"(");
		$enum=substr($enum, $off+1, strlen($enum)-$off-2);
		$keys=str_replace("'",null,explode(",",$enum));
		for($i=0;$i<sizeof($keys);$i++) {   $values[$keys[$i]]=$keys[$i];
		}

		return $values;
	}

}
?>