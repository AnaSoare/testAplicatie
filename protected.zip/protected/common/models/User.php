<?php

/**
 * This is the model class for table "user".
 *
 * The followings are the available columns in table 'user':
 * @property integer $id
 * @property string $last_name
 * @property string $first_name
 * @property string $username
 * @property string $email
 * @property string $password
 * @property string $status
 * @property integer $role_id
 * @property string $last_login
 * @property string $token_reset_password
 * @property string $created_at
 * @property integer $created by
 * @property string $updated_at
 * @property integer $updated_by
 * @property string $deleted_at
 * @property integer $deleted_by
 */


class User extends CActiveRecord
{
	/*----------------------------- Const Var --------------------------*/
	/* Status code. */
	const STATUS_ACTIVE 		= 'active';
	const STATUS_DISABLE 		= 'inactive';

	const MANAGER = 0;
	const EMPLOYEE = 1;

	/*--------------------------- Private Var --------------------------*/
	private $_identity;
	/*------------------------------------------------------------------*/


	/*---------------------------- Public Var --------------------------*/
	public $remember_me;

	public $new_password;
	public $password_retype;
	public $change_password;
	public $current_password;
	/*------------------------------------------------------------------*/


	public function tableName()
	{
		return 'user';
	}


	public function rules()
	{
		return array(

			array('password', 'length', 'max' => 1024),

			array('remember_me, created_at, updated_at, deleted_at, token_reset_password, password_retype, change_password', 'safe'),

			array('current_password, new_password', 'safe'),

			array('status', 'default', 'value' => self::STATUS_ACTIVE, 'setOnEmpty' => false, 'on' => array('insert', 'register')),
			array('role_id', 'default', 'value' => 2 , 'setOnEmpty' => false, 'on' => array('insert', 'register')),

			/* Global configuration. */
			//			array('username', 'unique', 'on' => array('insert', 'update', 'register')),
			array('email', 'unique', 'on' => array('insert', 'update', 'register')),


			/* Fields required on multiple scenario. */
			//			array('username', 'required', 'on' => array('insert', 'update', 'login', 'register'), 'message' => 'Campul este obligatoriu'),
			array('last_name', 'required', 'on' => array('insert', 'update'), 'message' => 'Campul este obligatoriu'),
			array('first_name', 'required', 'on' => array('insert', 'update'), 'message' => 'Campul este obligatoriu'),
			array('password', 'required', 'on' => array('insert', 'update'), 'message' => 'Campul este obligatoriu'),
			array('role_id', 'required', 'on' => array('insert', 'update', 'register'), 'message' => 'Campul este obligatoriu'),
			array('email', 'required', 'on' => array('insert', 'update'), 'message' => 'Campul este obligatoriu'),
			array('email', 'email', 'on' => array('insert', 'update', 'register'), 'message' => 'Email invalid'),
			/* --------------------------------------------------------------------------------------- */


			/* Resend Confirmation Email Scenario. */
			/* --------------------------------------------------------------------------------------- */


			/* Login Scenario. */
			array('password', 'required', 'on' => 'login', 'message' => 'Campul este obligatoriu.'),
			array('email', 'required', 'on' => 'login', 'message' => 'Campul este obligatoriu.'),
			/* --------------------------------------------------------------------------------------- */


			array('created_at', 'default', 'value' => new CDbExpression('NOW()'), 'setOnEmpty' => false, 'on' => array('insert')),
			array('created_by', 'default', 'value' => Yii::app()->user->id, 'setOnEmpty' => false, 'on' => array('insert')),


			array('updated_at', 'default', 'value' => new CDbExpression('NOW()'), 'setOnEmpty' => false, 'on' => array('update','changepassword')),
			array('updated_by', 'default', 'value' => Yii::app()->user->id, 'setOnEmpty' => false, 'on' => array('update','changepassword')),


			/* Search. */
			array('id, password, username, status, last_name, first_name, email, token_reset_password, created_at,created_by, updated_at, updated_by, deleted_at, deleted_by,', 'safe', 'on' => 'search'),
		);
	}


	public function relations()
	{
		return array(
			'role' => array(self::BELONGS_TO, 'Role', 'role_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'last_name' => 'Nume',
			'first_name' => 'Prenume',
			'username' => 'Utilizator',
			'password' => 'Parola',
			'status' => 'Status',
			'role_id' => 'Role',
			'email' => 'Email',
			'last_login_at' => 'Last Login At',
			'token_reset_password' => 'Token Reset Password',
			'created_at' => 'Creat la',
			'created by' => 'Creat de',
			'updated_at' => 'Modificat la',
			'updated_by' => 'Modificat de',
			'deleted_at' => 'Sters la',
			'deleted_by' => 'Sters de',



			'current_password' => 'Parola actuala',
			'new_password' => 'Parola noua',
			'password_retype' => 'Repeta parola',
			'change_password' => 'Schimba parola',
		);
	}

	public function login()
	{
		if ($this->_identity === null) {
			$this->_identity = new UserIdentity($this->email, $this->password);
			$this->_identity->authenticate();
		}


		if ($this->_identity->errorCode === UserIdentity::ERROR_NONE) {
			$duration = $this->remember_me ? 3600 * 24 * 30 : 0;

			Yii::app()->user->login($this->_identity, $duration);

			/* Save user log. */
			$this->updateUserLogs();

			return true;
		} else {
			/* Treat errors. */
			switch ($this->_identity->errorCode) {
				case UserIdentity::ERROR_USERNAME_INVALID:
					$this->addError('email', 'Invalid user.');
					break;

				case UserIdentity::ERROR_PASSWORD_INVALID:
					$this->addError('password', 'Parola invalida.');
					break;


				case UserIdentity::ERROR_STATUS_DISABLE:
					$this->addError('email', 'Contul este dezactivat.');

					Yii::app()->user->logout(true);
					break;
			}
			return false;
		}
	}

	public function updateUserLogs()
	{
		$user_id = Yii::app()->user->id;
		$user = User::model()->findByPk($user_id);


		if (isset($user)) {
			$user->last_login_at = new CDbExpression('NOW()');
			$user->update(array(
				'last_login_at'
			));

			$user->addUserLog('User login.');
		}
	}


	public function addUserLog($action_description = '')
	{
		$user_log = new UserLog();

		$user_log->user_id = $this->id;
		$user_log->ip = $_SERVER['REMOTE_ADDR'];
		$user_log->browser = $_SERVER['HTTP_USER_AGENT'];
		$user_log->description = $action_description;

		$user_log->save();
	}


	public function delete()
	{
		$this->deleted_at = new CDbExpression('NOW()');
		$this->deleted_by = Yii::app()->user->id;

		$this->save();

		return true;
	}


	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria = new CDbCriteria;



		$criteria->condition = "deleted_at IS NULL AND role_id = 2 AND materie_baza_id IS NOT NULL ";

		$criteria->compare('id', $this->id);
		$criteria->compare('last_name', $this->last_name, true);
		$criteria->compare('first_name', $this->first_name, true);
		$criteria->compare('username', $this->username, true);
		$criteria->compare('password', $this->password, true);
		$criteria->compare('email', $this->email, true);
		$criteria->compare('status', $this->status, true);
		$criteria->compare('role_id', $this->role_id);
		$criteria->compare('last_login_at', $this->last_login_at, true);
		$criteria->compare('token_reset_password', $this->token_reset_password, true);
		$criteria->compare('created_at', $this->created_at, true);
		$criteria->compare('created_by', $this->created_by);
		$criteria->compare('updated_at', $this->updated_at, true);
		$criteria->compare('updated_by', $this->updated_by);
		$criteria->compare('deleted_at', $this->deleted_at, true);
		$criteria->compare('deleted_by', $this->deleted_by);

		return new CActiveDataProvider($this, array(
			'criteria' => $criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return User the static model class
	 */
	public static function model($className = __CLASS__)
	{
		return parent::model($className);
	}
}
