<?php

class UserController extends Controller
{
	public $layout = '//layouts/main';
	public $defaultAction = 'login';


	public function filters()
	{
		return array(
			'accessControl',
		);
	}


	public function accessRules()
	{
		return array(
			array(
				'allow',
				'actions' => array('login', 'logout', 'register', 'changepassword', 'resetPassword'),
				'users' => array('*'),
			),


			array(
				'allow',
				'actions' => array('update', 'changepassword'),
				'users' => array('@'),
				//'roles' => array(2),
			),

			array(
				'allow',
				'actions' => array('showusers', 'create', 'admin'),
				'users' => array('@'),
			),

			array(
				'deny',
				'users' => array('*'),
			),
		);
	}


	public function actionView($id)
	{
		$this->render('view', array(
			'model' => $this->loadModel($id),
		));
	}

//
//	public function actionCreate()
//	{
//		$data = array();
//
//		$model = new User('insert');
//
//		$roles = Role::model()->findAllByAttributes(array('level' => 1));
//
//		$model->role_id = 1;
//
//		if (isset($_POST['User'])) {
//			$model->attributes = $_POST['User'];
//
//
//			if ($model->validate()) {
//
//				$model->username = strtolower($model->last_name) . '.' . strtolower($model->first_name);
//				$model->password = md5($model->password);
//
//				if ($model->save(false)) {
//
//
//					if ($model->change_password == true) {
//						$model->password = md5($model->new_password);
//					}
//
//					$this->redirect(array('site/index'));
//				}
//			}
//		}
//
//		$data['model'] = $model;
//		$data['roles'] = $roles;
//
//		$this->render('create', $data);
//	}
//
//
//	public function actionUpdate($id)
//	{
//		$data = array();
//
//		$roles = Role::model()->findAllByAttributes(array('level' => 1));
//
//		if (Yii::app()->user->checkAccess(User::MANAGER)) {
//			$model = $this->loadModel($id);
//		} else {
//			$model = $this->loadModel(Yii::app()->user->id);
//		}
//
//		if (isset($_POST['User'])) {
//			$model->attributes = $_POST['User'];
//
//			if ($model->change_password == true) {
//				$model->validatorList->add(
//					CValidator::createValidator(
//						'required',
//						$model,
//						'new_password, password_retype',
//						array(
//							'message' => 'Campul este obligatoriu.'
//						)
//					)
//				);
//
//				$model->validatorList->add(
//					CValidator::createValidator(
//						'compare',
//						$model,
//						'password_retype',
//						array(
//							'compareAttribute' => 'new_password',
//							'message' => 'Parolele nu coincid'
//						)
//					)
//				);
//			}
//
//			if ($model->validate()) {
//
//				if ($model->change_password == true) {
//					$model->password = md5($model->new_password);
//				}
//
//
//				if ($model->save(false)) {
//
//					$this->redirect(array('site/index'));
//				}
//			}
//		}
//
//		$data['model'] = $model;
//		$data['roles'] = $roles;
//
//
//		$this->render('update', $data);
//	}


	public function actionLogin()
	{
		$this->layout = '/layouts/login';
		$user_post_data = Yii::app()->request->getPost('User');

		if (!Yii::app()->user->isGuest) {
			$this->redirect(Yii::app()->homeUrl, true);
		}

		$user = new User('login');

		if (isset($user_post_data)) {

			$user->email = $user_post_data['email'];
			$user->password = $user_post_data['password'];

			if ($user->validate() && $user->login())
				$this->redirect(Yii::app()->user->returnUrl, true);
		}

		$data['user'] = $user;

		$this->render('login', $data);
	}


	public function actionLogout()
	{
		Yii::app()->user->logout(true);

		$this->redirect(['user/login'], true);
	}

	public function actionRegister()
	{
		$data = array();

		$this->layout = '//layouts/login';
		$user_post_data = Yii::app()->request->getPost('User');
		$roles = Role::model()->findAll();

		/* User already login. */
		if (!Yii::app()->user->isGuest) {
			$this->redirect(Yii::app()->homeUrl, true);
		}

		$user = new User('register');

		if (isset($user_post_data)) {
			$user->first_name = $user_post_data['first_name'];
			$user->last_name = $user_post_data['last_name'];
			$user->email = $user_post_data['email'];
			$user->password = $user_post_data['password'];

			if ($user->validate()) {
				$user->password = md5($user->password);


				if ($user->save()){
					$this->redirect(array('user/login'));
				}
			}else{
				Yii::app()->user->setFlash('errorRegister','Looks like you already have an account. Please sign in.');

				$this->redirect(array('user/login'));
			}
		}

		$data['user'] = $user;
		$data['roles'] = $roles;

		$this->render('partial/_register_form', $data);
	}


	public function actionResetPassword()
	{
		$this->layout = '//layouts/login';

		$form_view = '';

		$value = array(
			'success' => false,
			'errors' => array(),
			'redirect_url' => '',
		);

		$user_post_data = Yii::app()->request->getPost('User');
		//$user = new User('changepassword');
		$user = new User('signup');

		$redirect_url = Yii::app()->request->getParam('redirect_url');
		$http_status_code = 200;
		$is_ajax_request = Yii::app()->request->isAjaxRequest;
		$redirect_url = empty($redirect_url) ? $this->createUrl('user/login') : base64_decode($redirect_url);

		$email = $user_post_data['email'];


		if (Yii::app()->user->isGuest == true) {

			$user = User::model()->findByAttributes(array('email' => $email));

			if (isset($user) && !empty($user)) {

				$getToken = rand(0, 99999);
				$getTime = date("H:i:s");
				$user->token_reset_password = md5($getToken . $getTime);

				if ($user->update()) {

					EmailManager::sendEmailOnResetPassword($user);

					$value['success'] = true;

					Yii::app()->user->setFlash('success',
						"<h3>Forget Password ?</h3><br>Instructions for resetting your password have been sent to <b>$email</b>.
						<div class='form-actions text-center'> <a  href= " . Yii::app()->createAbsoluteUrl('user/login') . " class='showLoginForm' style='cursor: pointer;'>
						<button type='button' id='back-btn' class='btn green btn-outline'>Back to login</button>
						</a></div>
						");
				}

			} else {
				Yii::app()->user->setFlash('errorResetPassword', "Sorry, the address <b>$email</b> is not known to Test App.");

				$value['errors'] = 'Contul nu exista.';
			}

		} else {

			$value['success'] = true;
			$value['errors'] = array();

		}

		/*
			On ajax we response with a JSON and for non-ajax response
			we force redirect to specified url in the variable $redirect_url.
		*/
		if ($is_ajax_request == true) {

			header("Content-Type: application/json; charset=utf-8");
			header('HTTP/1.0 ' . $http_status_code);


			$value['redirect_url'] = $redirect_url;


			/* We response with a json. */
			echo CJSON::encode($value);

		} else {

			/* We force redirect to home page or to the specific redirect_url. */
			$this->redirect($redirect_url);

		}

	}

	public function actionChangePassword($token)
	{
		$data = array();

		$this->layout = '//layouts/login';

		$user_post_data = Yii::app()->request->getPost('User');

		$user = User::model()->findByAttributes(array('token_reset_password' => $token));

		if (!empty($user_post_data)) {

			if ($user_post_data['new_password'] == $user_post_data['password_retype']) {

				if ($user->token_reset_password == $token) {

					$user->password = md5($user_post_data['new_password']);
					$user->token_reset_password = null;

					$user->update();

					Yii::app()->user->setFlash('success', "<b>Parola a fost schimbata cu succes. <a  href= " . Yii::app()->createAbsoluteUrl('user/login') . " class='showLoginForm' style='cursor: pointer;'>Login</a></b>");

					//$this->redirect(array('partial/_changePassword', 'token' => $user->token_reset_password));
				}
			} else {
				Yii::app()->user->setFlash('errors', "Parolele nu sunt identice.");
				$this->redirect(array('partial/_changePassword', 'token' => $user->token_reset_password));
			}
		}


		$data['user'] = $user;

		$this->render('partial/_changePassword', $data);
	}

	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if (!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}


	public function actionIndex()
	{
		$dataProvider = new CActiveDataProvider('User');
		$this->render('index', array(
			'dataProvider' => $dataProvider,
		));
	}

	public function actionMyAccount()
	{
		$this->render('myaccount');
	}

	public function actionAdmin()
	{
		$data = array();

		$model = new User('search');
		$model->unsetAttributes();  // clear any default values
		if (isset($_GET['User']))
			$model->attributes = $_GET['User'];


		$data['model'] = $model;

		$this->render('admin', $data);
	}

	public function loadModel($id)
	{
		$model = User::model()->findByPk($id);
		if ($model === null)
			throw new CHttpException(404, 'The requested page does not exist.');
		return $model;
	}


	protected function performAjaxValidation($model)
	{
		if (isset($_POST['ajax']) && $_POST['ajax'] === 'user-form') {
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
