<?php

/**
 * This is the model class for table "task".
 *
 * The followings are the available columns in table 'task':
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property integer $project_id
 * @property integer $user_id
 * @property string $status_id
 * @property integer $assigned_to
 * @property string $due_date
 * @property string $task_priority_id
 * @property string $created_at
 * @property string $deleted_at
 * @property integer $deleted_by
 */
class Task extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */

	public $taskOrder;

	public function tableName()
	{
		return 'task';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('project_id, user_id, assigned_to, status_id, task_priority_id, deleted_by', 'numerical', 'integerOnly' => true),
			array('name', 'length', 'max' => 512),
			array('name, description, due_date, deleted_at', 'safe'),

			array('created_at', 'default', 'value' => new CDbExpression('NOW()'), 'setOnEmpty' => false, 'on' => array('insert')),
			array('user_id', 'default', 'value' => Yii::app()->user->id, 'setOnEmpty' => false, 'on' => array('insert')),


			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name', 'safe', 'on' => 'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		return array(
			'project' => array(self::BELONGS_TO, 'Project', 'project_id'),
			'taskPriority' => array(self::BELONGS_TO, 'TaskPriority', 'task_priority_id'),
			'user' => array(self::BELONGS_TO, 'User', 'user_id'),
			'priority' => array(self::BELONGS_TO, 'TaskPriority', 'task_priority_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'project_id' => 'Project',
			'user_id' => 'User',
			'status_id' => 'Status Id',
			'assigned_to' => 'Assinged To',
			'task_priority_id' => 'Task Priority Id',
			'due_date' => 'Due Date',
			'created_at' => 'Created At',
			'deleted_at' => 'Deleted At',
			'deleted_by' => 'Deleted By',
		);
	}

	public static function getNumberTaskByStatus($id){
		$count = '';

		$sqlCommandText = " SELECT COUNT(`id`) FROM `task`
		WHERE `status_id` = {$id}";

		$command = Yii::app()->db->createCommand($sqlCommandText);

		$count = $command->queryScalar();

		return $count;
	}

	public static function getNumberTaskByProject($id){
		$count = '';

		$sqlCommandText = " SELECT COUNT(`t`.`id`) FROM `task` `t`
 		LEFT JOIN `project` `p` ON `p`.`id` = `t`.`project_id`
		WHERE `t`.`project_id` = {$id} AND `p`.`status` = 'active'";

		$command = Yii::app()->db->createCommand($sqlCommandText);

		$count = $command->queryScalar();

		return $count;
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria = new CDbCriteria;

		if(isset($this->name) && !empty($this->name)){
			$criteria->addCondition ('( name LIKE "%'. $this->name .'%") ');
		}

		$criteria->addCondition("assigned_to=".Yii::app()->user->id);

		$criteria->with = array(
			'taskPriority'
		);

		$criteria->together = true;


		$criteria->compare('t.id', $this->id);
		$criteria->compare('t.name', $this->name, true);
		$criteria->compare('t.description', $this->description, true);
		$criteria->compare('t.project_id', $this->project_id);
		$criteria->compare('t.user_id', $this->user_id);
		$criteria->compare('t.assigned_to', $this->assigned_to);
		$criteria->compare('t.status_id', $this->status_id);
		$criteria->compare('t.due_date', $this->due_date, true);
		$criteria->compare('t.task_priority_id', $this->task_priority_id, true);
		$criteria->compare('t.created_at', $this->created_at, true);
		$criteria->compare('t.deleted_at', $this->deleted_at, true);
		$criteria->compare('t.deleted_by', $this->deleted_by);
		$criteria->compare('taskPriority.order', $this->taskOrder);

		return new CActiveDataProvider($this, array(
			'criteria' => $criteria,
			'sort' => array(
				'defaultOrder' => 'taskPriority.order	ASC',
			),

			'pagination' => array(
				'pageSize' => 10
			),
		));
	}


	public function searchByProject()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria = new CDbCriteria;

		$criteria->addCondition("project_id=".$_GET['id']);

		$criteria->with = array(
			'taskPriority'
		);

		$criteria->together = true;

		$criteria->compare('t.id', $this->id);
		$criteria->compare('t.name', $this->name, true);
		$criteria->compare('t.description', $this->description, true);
		$criteria->compare('t.project_id', $this->project_id);
		$criteria->compare('t.user_id', $this->user_id);
		$criteria->compare('t.assigned_to', $this->assigned_to);
		$criteria->compare('t.status_id', $this->status_id);
		$criteria->compare('t.due_date', $this->due_date, true);
		$criteria->compare('t.task_priority_id', $this->task_priority_id, true);
		$criteria->compare('t.created_at', $this->created_at, true);
		$criteria->compare('t.deleted_at', $this->deleted_at, true);
		$criteria->compare('t.deleted_by', $this->deleted_by);
		$criteria->compare('taskPriority.order', $this->taskOrder);

		return new CActiveDataProvider($this, array(
			'criteria' => $criteria,
			'sort' => array(
				'defaultOrder' => 'taskPriority.order	ASC',
			),

			'pagination' => array(
				'pageSize' => 10
			),
		));
	}

	public function searchByTaskStatus()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria = new CDbCriteria;

		$criteria->addCondition("status_id=".$_GET['id']);

		$criteria->with = array(
			'taskPriority'
		);

		$criteria->together = true;

		$criteria->compare('t.id', $this->id);
		$criteria->compare('t.name', $this->name, true);
		$criteria->compare('t.description', $this->description, true);
		$criteria->compare('t.project_id', $this->project_id);
		$criteria->compare('t.user_id', $this->user_id);
		$criteria->compare('t.assigned_to', $this->assigned_to);
		$criteria->compare('t.status_id', $this->status_id);
		$criteria->compare('t.due_date', $this->due_date, true);
		$criteria->compare('t.task_priority_id', $this->task_priority_id, true);
		$criteria->compare('t.created_at', $this->created_at, true);
		$criteria->compare('t.deleted_at', $this->deleted_at, true);
		$criteria->compare('t.deleted_by', $this->deleted_by);
		$criteria->compare('taskPriority.order', $this->taskOrder);

		return new CActiveDataProvider($this, array(
			'criteria' => $criteria,
			'sort' => array(
				'defaultOrder' => 'taskPriority.order	ASC',
			),

			'pagination' => array(
				'pageSize' => 10
			),
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Task the static model class
	 */
	public static function model($className = __CLASS__)
	{
		return parent::model($className);
	}
}
