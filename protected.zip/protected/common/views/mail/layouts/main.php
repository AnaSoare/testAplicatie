<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns:mc="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<style type="text/css">
		a {
			padding: 0;
			color: #505050;
			text-decoration: none
		}

		img {
			border: 0;
			height: auto;
			line-height: 100%;
			outline: none;
			text-decoration: none
		}

		table td {
			border-collapse: collapse;
			font-size: 12px;
			color: #555;
			font-family: Arial
		}

		h1,
		.h1 {
			color: #202020;
			display: block;
			font-family: Arial;
			font-size: 34px;
			font-weight: 700;
			line-height: 100%;
			text-align: left;
			margin: 0 0 10px
		}

		h2, .h2 {
			color: #202020;
			display: block;
			font-family: Arial;
			font-size: 30px;
			font-weight: 700;
			line-height: 100%;
			text-align: left;
			margin: 0 0 10px
		}

		h3,
		.h3 {
			color: #202020;
			display: block;
			font-family: Arial;
			font-size: 26px;
			font-weight: 700;
			line-height: 100%;
			text-align: left;
			margin: 0 0 10px
		}

		h4,
		.h4 {
			color: #202020;
			display: block;
			font-family: Arial;
			font-size: 22px;
			font-weight: 700;
			line-height: 100%;
			text-align: left;
			margin: 15px 0 10px
		}

		.preheaderContent div {
			color: #505050;
			font-family: Arial;
			font-size: 10px;
			line-height: 100%;
			text-align: left
		}

		.footerContent div {
			color: #707070;
			font-family: Arial;
			font-size: 12px;
			line-height: 125%;
			text-align: left
		}

		.footerContent img {
			display: inline
		}

		#social {
			background-color: #FAFAFA;
			border: 0
		}

		#utility {
			background-color: #FFF;
			border: 0
		}

		#monkeyRewards img {
			max-width: 190px
		}

		.ReadMsgBody,
		.ExternalClass {
			width: 100%
		}

		body,
		.templatePreheader {
			background-color: #FAFAFA
		}

		.preheaderContent div a:link,
		.preheaderContent div a:visited,
		.preheaderContent div a .yshortcuts,
		.headerContent a:link,
		.headerContent a:visited,
		.headerContent a .yshortcuts,
		.bodyContent div a:link,
		.bodyContent div a:visited,
		.bodyContent div a .yshortcuts,
		.leftMidColumnContent div a:link,
		.leftMidColumnContent div a:visited,
		.leftMidColumnContent div a .yshortcuts,
		.rightMidColumnContent div a:link,
		.rightMidColumnContent div a:visited,
		.rightMidColumnContent div a .yshortcuts,
		.leftLowerColumnContent div a:link,
		.leftLowerColumnContent div a:visited,
		.leftLowerColumnContent div a .yshortcuts,
		.centerLowerColumnContent div a:link,
		.centerLowerColumnContent div a:visited,
		.centerLowerColumnContent div a .yshortcuts,
		.rightLowerColumnContent div a:link,
		.rightLowerColumnContent div a:visited,
		.rightLowerColumnContent div a .yshortcuts,
		.footerContent div a:link,
		.footerContent div a:visited,
		.footerContent div a .yshortcuts {
			color: #369;
			font-weight: 400;
			text-decoration: underline
		}

		.bodyContent div,
		.leftMidColumnContent div,
		.rightMidColumnContent div,
		.leftLowerColumnContent div,
		.centerLowerColumnContent div,
		.rightLowerColumnContent div {
			color: #505050;
			font-family: Arial;
			font-size: 14px;
			line-height: 150%;
			text-align: left;
		}

		.bodyContent img,
		.leftMidColumnContent img,
		.rightMidColumnContent img,
		.leftLowerColumnContent img,
		.centerLowerColumnContent img,
		.rightLowerColumnContent img {
			display: inline;
			height: auto;
		}

		.leftMidColumnContent,
		.rightMidColumnContent,
		.leftLowerColumnContent,
		.centerLowerColumnContent,
		.rightLowerColumnContent {
			background-color: #FFF
		}

		#social div,
		#utility div {
			text-align: center
		}
	</style>
</head>


<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
	  style="width: 100% !important; -webkit-text-size-adjust: none; margin: 0; padding: 0; background-color: #FAFAFA;">
<div style="text-align: center;">
	<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"
		   style="width: 100% !important; height: 100% !important; margin: 0; padding: 0; background-color: #FAFAFA;">
		<tr>
			<td align="center" valign="top">

				<!-- // Begin Template Preheader \\ -->
				<table border="0" cellpadding="10" cellspacing="0" width="800" id="templatePreheader"
					   class="templatePreheader">
					<tr>
						<td valign="top" class="preheaderContent">
						</td>
					</tr>
				</table>
				<!-- // End Template Preheader \\ -->


				<table border="0" cellpadding="0" cellspacing="0" width="800" style="border: 1px solid #DDD;">
					<?php if(isset($cid) && !empty($cid)):?>
						<tr>
							<td align="center" valign="top">
								<!-- // Begin Template Header \\ -->
								<table border="0" cellpadding="0" cellspacing="0" width="800"
									   style="background-color: #FFF; border-bottom: 1px dashed #CCC; ">
									<tr>
										<td class="headerContent"
											style="color: #202020; font-family: Arial; font-size: 34px; font-weight: 700; line-height: 100%; text-align: center; vertical-align: middle; padding: 0;">

											<!-- // Begin Module: Standard Header Image \\ -->
											<img src="<?php echo $cid; ?>"
												 style="max-width: 800px !important; display: block; font-size: 0; line-height: 0; height:auto;"
												 mc:label="header_image" mc:edit="header_image" mc:allowdesigner
												 mc:allowtext/>
											<!-- // End Module: Standard Header Image \\ -->
										</td>
									</tr>
								</table>
								<!-- // End Template Header \\ -->
							</td>
						</tr>
					<?php endif; ?>

					<tr>
						<td align="center" valign="top">
							<!-- // Begin Template Body \\ -->
							<table border="0" cellpadding="0" cellspacing="0" width="800">
								<tr>
								</tr>
								<tr>
									<td colspan="4" valign="top" class="bodyContent">

										<!-- // Begin Module: Standard Content \\ -->
										<table border="0" cellpadding="20" cellspacing="0" width="100%">
											<tr>
												<td valign="top">
													<div mc:edit="std_content00">
														<?php
															if (!isset($content))
																$content = '';

															echo $content . "\n";
														?>
													</div>
												</td>
											</tr>
										</table>
										<!-- // End Module: Standard Content \\ -->

									</td>
								</tr>
							</table>
							<!-- // End Template Body \\ -->
						</td>
					</tr>
					<tr>
						<td align="center" valign="top">
							<!-- // Begin Template Footer \\ -->
							<table style="border-top: 1px dashed #CCC; background-color:#FFF;" border="0"
								   cellpadding="10" cellspacing="0" width="800">
								<tr>
									<td valign="top" class="footerContent">

									</td>
								</tr>
							</table>
							<!-- // End Template Footer \\ -->
						</td>
					</tr>
				</table>

				<br>

			</td>
		</tr>
	</table>
</div>
</body>
</html>